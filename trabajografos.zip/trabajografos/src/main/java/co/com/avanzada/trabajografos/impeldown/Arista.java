package co.com.avanzada.trabajografos.impeldown;

public class Arista {
	
	int to, w;

	public Arista(int to, int w) {
		this.to = to;
		this.w = w;
	}
}
