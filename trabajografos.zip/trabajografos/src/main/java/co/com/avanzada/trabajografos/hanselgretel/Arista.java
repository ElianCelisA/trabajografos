package co.com.avanzada.trabajografos.hanselgretel;

public class Arista {
	
	public int v;
	public int w;
	public boolean drawn;

	public Arista(int v, int w) {
		this.v = v;
		this.w = w;
		this.drawn = false;
	}
}
